
--CASE STUDY 1.
SELECT*FROM Customer
select*from Transactions
SELECT*FROM prod_cat_info

  --Q1 being
SELECT 'Transactions'as table_name, COUNT(transaction_id) as count_record
from Transactions as transaction_count

select 'Customer'as table_name,COUNT(customer_Id) as count_record
from Customer as coustomer_count

select 'prod_cat_info' as table_name, COUNT(prod_cat_code) as count_record
from prod_cat_info as prod_cat_count

--Q2 being
select COUNT(*) as total_return
from Transactions
where CAST (total_amt as float)<0

--Q3
select *,
convert(date,tran_date,105) as date_convert
from Transactions

--Q4
select
DATEDIFF(day,min(convert(date,tran_date,105)),max(convert(date, tran_date,105)) ) as diff_day, 
DATEDIFF(month,min(convert(date,tran_date,105)),max(convert(date, tran_date,105)) ) as diff_month,
DATEDIFF(year,min(convert(date,tran_date,105)),max(convert(date, tran_date,105)) ) as diff_year
from Transactions

--Q5 being
select prod_cat
from prod_cat_info
where prod_subcat='DIY'

--data analysis
--Q1 being
select top 1 
Store_type,count(transaction_id) as count_transaction
from Transactions
group by Store_type
order by count(transaction_id) desc

--Q2 being
SELECT Gender, COUNT(customer_id) as count_cus 
from Customer
where Gender in ('M','f')
group by Gender

--Q3 BEING
SELECT top 1
city_code,count (customer_id) as count_cust
from Customer
group by city_code
order by count (customer_id) desc

--Q4 being
SELECT COUNT(prod_subcat) as count_cat
from prod_cat_info
where prod_cat = 'BookS'

--Q5 being
select  MAX  (Qty) as order_
from Transactions

--Q6
select sum ( cast (total_amt as float)) as amount
from Transactions as x
left join prod_cat_info as y on x.prod_cat_code=y.prod_cat_code
and prod_sub_cat_code=prod_sub_cat_code
where prod_cat in ('books','electronics')

--Q7 being
select COUNT (customer_id) as cus_count
from Customer where customer_Id in
(
select cust_id
from Transactions as x
left join Customer as y on x.cust_id=y.customer_Id
where total_amt not like '-%'
group by cust_id
having COUNT (transaction_id) >10
)

--Q8 being
select sum( cast(total_amt as float)) as amount
from Transactions as x
left join prod_cat_info as y on x.prod_cat_code=y.prod_cat_code 
and prod_sub_cat_code=prod_sub_cat_code
where prod_cat in ('clothing','electronics') and Store_type='flagship store'

--Q9 being
select prod_cat, SUM (cast (total_amt as float)) as tot_rev
from Transactions as x
left join Customer as y on x.cust_id=y.customer_Id 
left join prod_cat_info as z on z.prod_cat_code=x.prod_cat_code
where prod_cat='Electronics' and Gender='M' 
group by prod_cat

 --Q10 being
 select 
 (select sum (total_amt)
 from Transactions) *100 as percantage_of_sale
 sum ( cast(qty as numeric))*100 as percantage_of_return 
 from Transactions as x
 left join prod_cat_info as y
 on x.prod_cat_code=y.prod_cat_code
 order by sum

 SELECT TOP 5 
PROD_SUBCAT, (SUM(TOTAL_AMT)/(SELECT SUM(TOTAL_AMT) FROM Transactions))*100 AS PERCANTAGE_OF_SALES, 
(COUNT(CASE 
WHEN QTY< 0
THEN QTY 
ELSE NULL
END)/SUM( cast (QTY as numeric))*100 [percantage as return]
FROM Transactions AS X 
INNER JOIN prod_cat_info AS Y ON X.prod_cat_code = Y.prod_cat_code AND PROD_SUBCAT_CODE= prod_subcat_code
GROUP BY PROD_SUBCAT
ORDER BY SUM(TOTAL_AMT) DESC

--Q11 being
select cust_id, sum (total_amt) as revenue
from Transactions
where cust_id in 
(select customer_Id from Customer
where DATEDIFF(year,convert (date,dob,105),GETDATE())between 25 and 35)
and CONVERT(date,tran_date,105)
between dateadd(Day,-30,(select max (convert (date, tran_date,105)) from Transactions))
and (select MAX ( convert (date,tran_date,105))from Transactions)
group by cust_id


--Q12 being
SELECT TOP 1
PROD_CAT, SUM(TOTAL_AMT) as [total]FROM Transactions as x
left JOIN prod_cat_info as y ON x.prod_cat_code= y.prod_cat_code 
WHERE TOTAL_AMT < 0 and 
CONVERT(date, TRAN_date, 105) BETWEEN DATEADD(MONTH,-3,(SELECT MAX(CONVERT(DATE,tran_date,105)) FROM Transactions)) 
	 and (SELECT MAX(CONVERT(DATE,tran_date,105)) FROM Transactions) 
GROUP BY PROD_CAT
ORDER BY 2 DESC


--Q13 being

SELECT  STORE_TYPE, SUM( cast(TOTAL_AMT as float)) TOT_SALES, SUM (cast (QTY as numeric)) TOT_QTY
FROM Transactions
GROUP BY STORE_TYPE
HAVING SUM(TOTAL_AMT ) >=ALL (SELECT SUM (cast(TOTAL_AMT as float) ) FROM Transactions GROUP BY STORE_TYPE)
AND SUM(cast (QTY as numeric)) >=ALL (SELECT SUM (CAST( QTY as numeric )) FROM Transactions GROUP BY STORE_TYPE)

--Q14 being
SELECT PROD_CAT, AVG(TOTAL_AMT) AS AVERAGE
FROM Transactions as x
left JOIN prod_cat_info as y ON x.prod_cat_code=y.prod_cat_code
GROUP BY PROD_CAT
HAVING AVG(TOTAL_AMT)> (SELECT AVG(TOTAL_AMT) FROM Transactions) 

--Q15 being
SELECT PROD_CAT, PROD_SUBCAT, AVG(TOTAL_AMT) AS AVERAGE_REV, SUM(TOTAL_AMT) AS REVENUE
FROM Transactions as x
left JOIN prod_cat_info as y ON x.prod_cat_code= y.prod_cat_code
WHERE PROD_CAT IN
(
SELECT TOP 5 
PROD_CAT
FROM Transactions as x
left JOIN prod_cat_info as y ON x.prod_cat_code= y.prod_cat_code
GROUP BY PROD_CAT
ORDER BY SUM( CAST( QTY as numeric )) DESC
)
GROUP BY PROD_CAT, PROD_SUBCAT 